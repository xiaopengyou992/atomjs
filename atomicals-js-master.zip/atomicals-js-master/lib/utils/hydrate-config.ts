import { ConfigurationInterface } from '../interfaces/configuration.interface';
export function hydrateConfig(config: ConfigurationInterface) {
    return config;
}
